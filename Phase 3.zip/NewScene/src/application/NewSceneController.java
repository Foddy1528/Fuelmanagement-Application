package application;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

public class NewSceneController implements Initializable {

    @FXML
    private ChoiceBox<String> brandChoiceBox;

    @FXML
    private ChoiceBox<String> modelChoiceBox;

    @FXML
    private ChoiceBox<String> fuelTankChoiceBox;

    @FXML
    private Label selectedBrandLabel;

    @FXML
    private Label selectedModelLabel;

    @FXML
    private Label selectedFuelLabel;

    private final String[] brands = { "BMW", "Toyota" };
    private final Map<String, String> modelToFuel = new HashMap<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Fill model-to-fuel data
        modelToFuel.put("BMW 7 Series 740Li", "7.9l/100km");
        modelToFuel.put("BMW 7 Series 730Ld", "5.7l/100km");
        modelToFuel.put("Toyota HILUX 2.4 GD-6", "7.1l/100km");
        modelToFuel.put("Toyota HILUX 2.8 GD-6", "7.6l/100km");
        modelToFuel.put("Toyota QUANTUM", "8.5l/100km");
        modelToFuel.put("Toyota ETIOS", "5.9l/100km");
        modelToFuel.put("Toyota COROLLA CROSS", "6.8l/100km");

        // Step 1: Populate brand dropdown
        brandChoiceBox.getItems().addAll(brands);

        // Step 2: When a brand is selected, show models and update label
        brandChoiceBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null) return;

            selectedBrandLabel.setText(newVal);

            modelChoiceBox.getItems().clear();
            modelToFuel.keySet().stream()
                    .filter(model -> model.startsWith(newVal))
                    .forEach(modelChoiceBox.getItems()::add);

            // Clear dependent selections
            selectedModelLabel.setText("");
            selectedFuelLabel.setText("");
            fuelTankChoiceBox.getItems().clear();
        });

        // Step 3: When a model is selected, show fuel info and update label
        modelChoiceBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null) return;

            selectedModelLabel.setText(newVal);

            String fuel = modelToFuel.get(newVal);
            fuelTankChoiceBox.getItems().clear();

            if (fuel != null) {
                fuelTankChoiceBox.getItems().add(fuel);
                fuelTankChoiceBox.getSelectionModel().selectFirst();
                selectedFuelLabel.setText(fuel);
            }
        });

        // Step 4: Update fuel label if changed manually
        fuelTankChoiceBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                selectedFuelLabel.setText(newVal);
            }
        });
    }
}


